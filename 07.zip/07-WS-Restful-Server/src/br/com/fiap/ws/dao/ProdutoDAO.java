package br.com.fiap.ws.dao;

import br.com.fiap.ws.entity.Produto;

public interface ProdutoDAO extends GenericDAO<Produto, Integer>{

}
